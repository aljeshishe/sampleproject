from pyspark.sql import SparkSession
from pea import rfm
import os
print(os.environ)
os.environ['DATABRICKS_ADDRESS'] = 'https://eastus2.azuredatabricks.net'
os.environ['DATABRICKS_API_TOKEN'] = 'dapi28f781720637bc76010f0a8f67955587'
os.environ['DATABRICKS_CLUSTER_ID'] = '0326-214312-tempo684'
os.environ['DATABRICKS_ORG_ID'] = '81749252745250'
os.environ['DATABRICKS_PORT'] = '8787'

builder = SparkSession.builder.appName("pea")
# builder = builder.config('spark.ui.showConsoleProgress", False)
spark = builder.getOrCreate()
spark.sql("show databases").show()
spark.sql("show tables from default").show()

df = spark.read.table("p_nas_italy_dimar.idpos_transaction_fact") \
    .where("prod_category in ('RASATURA E DEPILAZIONE') and prod_subcategory like '%UOMO%' and consumer_id!='0'")
chart = rfm.before_after(df=df,
                         promo_filter="prod_brand='MACH3'",
                         grouping_filter="",
                         groupby_col="prod_brand",
                         agg="sum_sales_amount")
chart.show()
