from pprint import pprint
from pyspark.sql import SparkSession
import pea

# This example shows advanced validation usage.
from pea.validation import Validator, ConsoleOutput

builder = SparkSession.builder.appName("pea")

builder = builder.config('spark.ui.showConsoleProgress', False)
spark = builder.getOrCreate()

v = Validator()

# list tables to validate
pprint(v.tables)

# list rules used during validation
pprint(v.rules)

# modify rules
v.rules['tables']['idpos_transaction_fact']['rules'] = []

# enable PASS messages during validation, show 10 samples for validation FAILs
output = ConsoleOutput(samples=10, show_pass=True)

# validate dataframes. They could be read from parquet files
v.validate_dataframes(output=output,
                      idpos_transaction_fact=spark.read.table('p_nas_italy_dimar.idpos_transaction_fact'),
                      # idpos_transaction_detail_fact=spark.read.table('p_nas_italy_dimar.idpos_transaction_detail_fact'),
                      idpos_consumer_dim=spark.read.table('p_nas_italy_dimar.idpos_consumer_dim'),
                      idpos_store_dim=spark.read.table('p_nas_italy_dimar.idpos_store_dim'),
                      # idpos_prod_dim_df=spark.read.table('p_nas_italy_dimar.idpos_prod_dim_df')
                      )
