# Databricks notebook source
import pandas
import pyarrow
import pyspark

# COMMAND ----------

dbutils.library.install(
    "dbfs:/FileStore/jars/777bd8bd_f563_4e29_8759_59dccac4d98f-pg_ds_cf_shopperpea_0_0_4_rfm_py3_7-53249.egg")
dbutils.library.installPyPI("plotly", version="4.5.4")

# COMMAND ----------

# MAGIC %sql 
# MAGIC ANALYZE TABLE p_nas_italy_dimar.idpos_transaction_fact COMPUTE STATISTICS;

# COMMAND ----------

from pea import rfm

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

df = spark.read.table("p_nas_italy_dimar.idpos_transaction_fact") \
    .where("prod_category in ('RASATURA E DEPILAZIONE') and prod_subcategory like '%UOMO%' and consumer_id!='0'")

# COMMAND ----------

# how much spent all brands before and after buying MACH3
chart = rfm.before_after(df=df,
                         promo_filter="prod_brand='MACH3'",
                         grouping_filter="",
                         groupby_col="prod_brand",
                         agg="sum_sales_amount")
display(chart)

# COMMAND ----------

display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

# how often(average days between purchases) all brands bought before and after buying MACH3
chart = rfm.before_after(df=df,
                         promo_filter="prod_brand='MACH3'",
                         grouping_filter="",
                         groupby_col="prod_brand",
                         agg="avg_purch_cycle")
display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

# how much spent on competitive products before and after buying MACH3
chart = before_after_chart(df=df,
                           promo_filter="prod_brand='MACH3'",
                           grouping_filter="prod_brand in ('GILLETTE', 'BIC')",
                           groupby_col="prod_brand",
                           agg="sum_sales_amount")
display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

# how often competitive products bought before and after buying MACH3
chart = rfm.before_after(df=df,
                         promo_filter="prod_brand='MACH3'",
                         grouping_filter="prod_brand in ('GILLETTE', 'BIC')",
                         groupby_col="prod_brand",
                         agg="avg_purch_cycle")
display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

# how much spent before and after buying GILLETTE BLUE II
chart = rfm.before_after(df=df,
                         promo_filter="prod_name like 'GILLETTE BLUE II%'",
                         grouping_filter="",
                         groupby_col="prod_brand",
                         agg="sum_sales_amount")
display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

# how often spent before and after buying GILLETTE BLUE II
chart = rfm.before_after(df=df,
                         promo_filter="prod_name like 'GILLETTE BLUE II%'",
                         grouping_filter="",
                         groupby_col="prod_brand",
                         agg="avg_purch_cycle")
display(chart)

# COMMAND ----------

rfm.bar_chart(df=chart, x_labels_column="time_flag").show()

# COMMAND ----------

spark.sql("clear cache")
