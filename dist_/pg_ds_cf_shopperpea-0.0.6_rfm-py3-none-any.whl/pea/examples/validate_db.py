from pyspark.sql import SparkSession
import pea

# This example shows basic validation usage
from pea.validation import Validator

builder = SparkSession.builder.appName("pea")
builder = builder.config('spark.ui.showConsoleProgress', False)
spark = builder.getOrCreate()

# run validation over whole p_nas_italy_dimar database
Validator().validate_db(spark=spark, db_name='p_nas_italy_dimar')
