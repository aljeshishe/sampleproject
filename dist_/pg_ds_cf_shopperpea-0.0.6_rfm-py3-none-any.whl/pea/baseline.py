import numpy as np
import pandas as pd
import logging

from .utils import roll, lr, rleid

LOGGER = logging.getLogger(__name__)


def run_baseline(
    x: pd.DataFrame,
    Threshold_lowSales=100,
    Threshold_price_discount=5,
    Threshold_nonprice_promo=1.5,
    CONF_RefPrice_Window=16,
    CONF_ProdLaunch=-1,
    CONF_NonPrice_Window=13,
    CONF_NonPrice_Adjust=False,
    CONF_Base_window=13,
    CONF_InOut_Period=26,
    CONF_InOut_Logic=4,
    CONF_VSODadj=True,
    CONF_SeasonAdj=True,
    doBrand=True,
    doCategory=True,
    doMfrForm=False,
    doMfrCategory=True,
    parallel=False,
    debug=False,
    doPGHierarchy=False,
    CONF_RefPrice_Logic=4,
    CONF_HLBaseWeeks_Distrib=1,
) -> pd.DataFrame:

    return pd.DataFrame()


def prep_weekly_pos_for_pea(df, Threshold_lowSales, CONF_ProdLaunch, debug) -> pd.DataFrame:
    if df["abs_unit"].max() < Threshold_lowSales:
        raise ValueError("ERROR: Maximum unit sales in dataset is below low-sales threshold.")
    df["Product"] = (
        df.groupby(["Retailer", "Category", "barcode"], as_index=False, sort=False).ngroup()
    ) + 1

    if "Promo_Price" in df and df["Promo_Price"].notnull().all():
        df = df.rename(columns={"Promo_Price": "Price"})
        df.loc[df["Price"].isnull(), "Price"] = df["abs_value"] / df["abs_unit"]
        df.groupby("Product").fillna(method="ffill", inplace=True)
    else:
        df["Price"] = df["abs_value"] / df["abs_unit"]
        df["Price"] = df.groupby("Product", as_index=False)["Price"].ffill()
        df["Price"] = df.groupby("Product", as_index=False)["Price"].bfill()

    if "Promo" in df:
        if (~df["Promo"].isin([0, 1, np.nan])).all():
            raise ValueError("Column Promo provided, but a value other than 0/1 or empty found.")
        df.rename(columns={"Promo": "Promo_from_POS"}, inplace=True)
        if df["Promo_from_POS"].notnull().any():
            LOGGER.debug("Taking Promo Flag from POS data.")

    if "In_Out" in df:
        all_values_expected = df["In_Out"].isin([0, 1]) | df["In_Out"].isnull()
        if not all_values_expected.all():
            raise ValueError("Column In_Out provided, but a value other than 0/1 or empty found.")
        df.rename(columns={"In_Out": "In_Out_from_POS"}, inplace=True)

    if "NonPromo_Price" in df and df["NonPromo_Price"].notnull().any():
        try:
            df["NonPromo_Price"] = pd.to_numeric(df["NonPromo_Price"])
        except ValueError:
            raise ValueError("Column NonPromo_Price provided, but found non-numeric values in it.")
        if "Ref_Price" in df:
            df.drop("Ref_Price", axis=1, inplace=True)
        df.rename(columns={"NonPromo_Price": "Ref_Price"})
        if df["Ref_Price"].notnull().any():
            LOGGER.debug("Found NonPromo_Price to be provided & using it.")

    if "Phase_Out" in df:
        all_values_expected = df["Phase_Out"].isin([0, 1]) | df["Phase_Out"].isnull()
        if not all_values_expected.all():
            raise ValueError(
                "Column Phase_Out provided, but a value other than 0/1 or empty found."
            )
        df.rename(columns={"Phase_Out": "Phase_Out_from_POS"}, inplace=True)

        if df["Phase_Out_from_POS"].notnull().any():
            LOGGER.debug("Taking Phase_Out Product flag from POS data.")

    # OVERWRITE New_Prod
    if "New_Prod" in df:
        all_values_expected = df["New_Prod"].isin([0, 1]) | df["New_Prod"].isnull()
        if not all_values_expected.all():
            raise ValueError("Column New_Prod provided, but a value other than 0/1 or empty found.")
        df.rename(columns={"New_Prod": "New_Prod_from_POS"}, inplace=True)
        if df["New_Prod_from_POS"].notnull().any():
            LOGGER.debug("Taking New_Prod Product flag from POS data.")

    if df["WeekName"].nunique() <= 13:
        raise ValueError(
            "You provided only {} weeks of POS data. We require at least 14 weeks!".format(
                df["WeekName"].nunique()
            )
        )

    df.sort_values(["Product", "WeekName"], ascending=True, inplace=True)
    product_gb = df.groupby("Product", as_index=False)
    df["New_Prod"] = (product_gb.cumcount() < CONF_ProdLaunch) | (
        product_gb.cumsum()["abs_unit"] <= Threshold_lowSales
    )

    df.sort_values(["Product", "WeekName"], ascending=False, inplace=True)
    product_gb = df.groupby("Product", as_index=False)
    df["Phase_Out"] = product_gb["abs_unit"].cumsum() <= Threshold_lowSales

    df.sort_values(["Product", "WeekName"], ascending=True, inplace=True)

    return df


def calculate_ref_price(
    df: pd.DataFrame,
    CONF_RefPrice_Window: int = 16,
    Threshold_price_discount: int = 5,
    Threshold_lowSales: int = 100,
    CONF_RefPrice_Logic: int = 4,
    debug: bool = False,
) -> pd.DataFrame:
    LOGGER.debug("Reference Price Logic: #{}, (PEA)".format(CONF_RefPrice_Logic))
    if "Ref_Price" in df and df["Ref_Price"].notnull().any():
        df = df.groupby("Product").apply(
            lambda df: df.assign(ref_price_provided=df["Ref_Price"].notnull().any())
        )
        df_ref_price_provided = df[df["ref_price_provided"]]
        df = df[~df["ref_price_provided"]]
    else:
        df_ref_price_provided = pd.DataFrame(columns=df.columns)

    if "Ref_Price" in df and df["RefPrice"].notnull().all():
        pass
    else:
        df["Ref_Price_right"] = roll(
            df,
            "Price",
            window=CONF_RefPrice_Window,
            fun=np.max,
            align="right",
            fill="NA",
            by="Product",
        )
        df["Ref_Price_right"] = df.groupby("Product", as_index=False)["Ref_Price_right"].bfill()
        df["Ref_Price_right"] = df.groupby("Product", as_index=False)["Ref_Price_right"].ffill()

        df["Ref_Price_left"] = roll(
            df,
            "Price",
            window=CONF_RefPrice_Window,
            fun=np.max,
            align="left",
            fill="NA",
            by="Product",
        )
        df["Ref_Price_left"] = df.groupby("Product", as_index=False)["Ref_Price_left"].ffill()

        thresh = df["Price"] * Threshold_price_discount / 100 / 2

        right_diff = (df["Ref_Price_right"] - df["Price"]).abs()
        right_nan_idx = right_diff.isnull()
        idx_right = right_diff < thresh
        idx_right |= right_nan_idx

        left_diff = (df["Ref_Price_left"] - df["Price"]).abs()
        left_nan_idx = left_diff.isnull()
        idx_left = left_diff < thresh
        idx_left |= left_nan_idx
        df["Ref_Price_NonDiscounted"] = idx_right & idx_left

        # Group weeks together by their "NonDiscounted" status and get the length
        # of discounted periods (0 length for non-discounted periods)
        df["rleid_refprice_nondicounted"] = rleid(df["Ref_Price_NonDiscounted"])

        keys = ["Product", "rleid_refprice_nondicounted"]
        s = df.groupby(keys, as_index=False, sort=False).size()
        s.name = "Ref_Price_NonDiscounted_Len"
        df = df.merge(s, how="left", right_index=True, left_on=keys)

        df.loc[df["Ref_Price_NonDiscounted"], "Ref_Price_NonDiscounted_Len"] = 0
        # We get the min price within each section:

        # df["Ref_Price_NonDiscounted_MinPrice"] = (
        #     df.groupby(keys)
        #     .apply(lambda df: df[["Ref_Price_left", "Ref_Price_right"]].min(axis=1))
        #     .reset_index(drop=True)
        # )
        df["Ref_Price_NonDiscounted_MinPrice"] = df[["Ref_Price_left", "Ref_Price_right"]].min(
            axis=1
        )
        df["Ref_Price_NonDiscounted_MinPrice"] = df.groupby(keys)[
            "Ref_Price_NonDiscounted_MinPrice"
        ].transform(lambda s: s.min())

        df["rleid2"] = rleid(
            df["Ref_Price_NonDiscounted"],
            df["Ref_Price_right"] == df["Price"],
            df["Ref_Price_left"] == df["Price"],
        )
        # rleid2.max() == 16347
        keys = ["Product", "rleid2"]
        refined_price = df.groupby(keys).apply(select_ref_price)
        refined_price.index = refined_price.index.droplevel(keys)
        df["Ref_Price_NonDiscounted_MinPrice"] = refined_price

        # select wisely ;-)  See excel simulator for the key idea.
        cond = df["Ref_Price_left"] < df["Ref_Price_right"]
        cond &= left_diff <= right_diff
        df["Ref_Price"] = np.where(cond, df["Ref_Price_left"], df["Ref_Price_right"])

        # For discounted periods longer than the defined max, we drop the reference price:
        ref_price_len_gt_win = df["Ref_Price_NonDiscounted_Len"] > CONF_RefPrice_Window
        max_ref_price = df.loc[
            ref_price_len_gt_win, ["Ref_Price_NonDiscounted_MinPrice", "Price"]
        ].max(axis=1)
        df.loc[ref_price_len_gt_win, "Ref_Price"] = max_ref_price

        if CONF_RefPrice_Logic == 2:
            # in case option 2 - we avoid smoothing. Just use the ref_price we have built so far.
            # DT[, Ref_Price := Ref_Price_NonDiscounted_MinPrice]
            pass
        elif CONF_RefPrice_Logic == 3:
            # # Implementation of smoothing - option #3 for CONF_RefPrice_Logic.
            # # We create buckeets via the rleid function that tag each period where a price is
            # behaving consistently. In case it is a period
            # # where we never see the ref_price as actual price, it is an "artifcact" created from
            # the left/right logic above and needs to be
            # # corrected down - copying the ref_price from the left.
            # TODO: implement
            raise NotImplementedError()

        elif CONF_RefPrice_Logic == 4:
            # DE15159 To remove jumps in reference price when on CONF_RefPrice_Window
            # we don't have Ref_price == Price
            df["min_refprice_left"] = roll(
                df,
                "Ref_Price",
                window=CONF_RefPrice_Window,
                fun=np.min,
                fill="partial",
                align="left",
                by="Product",
            )
            df["min_refprice_right"] = roll(
                df,
                "Ref_Price",
                window=CONF_RefPrice_Window,
                fun=np.min,
                fill="partial",
                align="right",
                by="Product",
            )

            ref_price_idx = df["Ref_Price"] > df["min_refprice_left"]
            ref_price_idx &= df["min_refprice_left"] == df["min_refprice_right"]
            ref_price_idx &= df["min_refprice_left"] >= df["Price"]

            df.loc[ref_price_idx, "Ref_Price"] = df.loc[ref_price_idx, "min_refprice_left"]

            df.drop(["min_refprice_left", "min_refprice_right"], axis=1, inplace=True)

        else:
            raise ValueError("Unknown CONF_RefPrice_Logic value. Supported is 1, 2, 3 and 4.")

        # clean up:
        if not debug:
            cols_to_drop = [
                "Ref_Price_right",
                "Ref_Price_left",
                "Ref_Price_NonDiscounted",
                "Ref_Price_NonDiscounted_MinPrice",
                "Ref_Price_NonDiscounted_Len",
                "rleid_refprice_nondicounted",
                "rleid2",
            ]
            df.drop(cols_to_drop, axis=1, inplace=True)
        if not df_ref_price_provided.empty:
            df = pd.concat([df, df_ref_price_provided], sort=False)
            df.drop("ref_price_provided", axis=1, inplace=True, errors="ignore")

        # we do NA handling:
        df.loc[:, ["Ref_Price", "Price"]] = df.groupby("Product", as_index=False)[
            ["Ref_Price", "Price"]
        ].ffill()
        df.loc[:, ["Ref_Price", "Price"]] = df.groupby("Product", as_index=False)[
            ["Ref_Price", "Price"]
        ].bfill()
        df.loc[df["Ref_Price"].isnull(), "Ref_Price"] = df.loc[df["Ref_Price"].isnull(), "Price"]

        df["Discount"] = (df["Ref_Price"] - df["Price"]) * 100 / df["Ref_Price"]

        df["Promo_TPR"] = df["Discount"] > Threshold_price_discount
    return df


def calculate_non_price_promo_peaks(
    df, CONF_NonPrice_Window=13, Threshold_nonprice_promo=1.5, CONF_NonPrice_Adjust=False,
) -> pd.DataFrame:
    df["Base_Week"] = ~df["Promo_TPR"]
    df = calculate_base(df, val="unit", Base_window=CONF_NonPrice_Window)

    cond = ~df["Promo_TPR"]
    df = df.assign(Promo_NonPrice=False)
    df.loc[cond, "Promo_NonPrice"] = df["abs_unit"] > Threshold_nonprice_promo * df["Base_unit"]

    if CONF_NonPrice_Adjust:
        pass
    df.loc[df["Promo_TPR"], "Promo_NonPrice"] = False
    df["Promo"] = df["Promo_TPR"] | df["Promo_NonPrice"]
    df.drop(["Base_Week", "Base_unit"], axis=1, inplace=True)
    return df


def calculate_base(df, val="unit", Base_window=13):
    colname = "Base_{}".format(val)
    df = df.assign(**{colname: np.nan})

    cond = df["Base_Week"]
    base_col = roll(
        df.loc[cond, :],
        "abs_{}".format(val),
        window=Base_window,
        fun=np.mean,
        align="center",
        fill="partial",
        by="Product",
    )
    df.loc[cond, colname] = base_col
    df[colname] = df.groupby("Product")[colname].transform(lambda s: lr(s, 0))
    return df


def select_ref_price(df):
    min_price = df[["Ref_Price_left", "Ref_Price_right"]].min(axis=1)
    cond = df["Ref_Price_NonDiscounted_MinPrice"].fillna(0) <= df["Price"].max()
    data = np.where(cond, min_price, df["Ref_Price_NonDiscounted_MinPrice"])
    index = df.index
    return pd.Series(data=data, index=index)
