from typing import Any, Tuple, Union

import pandas as pd
import pyspark.sql.functions as pf
from pyspark.sql import DataFrame, SparkSession

try:
    import matplotlib.pyplot as plt
except ImportError:
    pass


def count_nulls(df: DataFrame) -> DataFrame:
    """Show null count for each column in Spark DataFrame.

    Analogue of pd.DataFrame().isnull().sum().
    
    Arguments:
        df {DataFrame} -- Spark DataFrame.
    
    Returns:
        DataFrame -- Same columns as in input df, values are null counts in each column.
    """
    cols = []
    df_len = df.count()
    for c in df.columns:
        col = pf.col(c)
        null_count = pf.count(pf.when(pf.isnull(col) | pf.isnan(col), 1)).alias(c)
        null_pct = (null_count / df_len).alias("{}_pct".format(c))
        cols.append(null_count)
        cols.append(null_pct)
    return df.select(*cols)


def plot_variable_over_time(
    df: Union[DataFrame, pd.DataFrame],
    variable: str,
    title: str = None,
    xlabel: str = "Month",
    ylabel: str = None,
    kind="bar",
    agg="sum",
    show=False,
    **kwargs
) -> Tuple[Any, pd.DataFrame]:
    """Plot variable distribution over months.

    Calculate months from `transaction_datetm` in form of `YYYYMM`, and calculate distribution of
    variable over months.
    
    Arguments:
        df {DataFrame} -- Spark DataFrame.
        variable {str} -- Column name to use for calculating distribution.
    
    Keyword Arguments:
        title {str} -- Resulting plot title (default: `{variable} distribution over time`)
        xlabel {str} -- Plot x-axis label. (default: {"Month"})
        ylabel {str} -- Plot y-axis label. (default: {variable})
        kind {str} -- Plot kind (any value eligible for pd.df.plot). (default: {"bar"})
        agg {str} -- Aggregation to use on the variable column. (default: {"sum"})
        show {bool} -- Whether to show the plot immediatly. (default: {False})
    
    Returns:
        Tuple[Axes, pd.DataFrame] -- Axes with plotted distribution and the data used for the plot.
    """
    if isinstance(df, DataFrame):
        if "Month" not in df:
            t = pf.year(pf.col("transaction_datetm")) * 100 + pf.month(pf.col("transaction_datetm"))
            df = df.withColumn("Month", t)

        plot_df = df.groupby("Month").agg({variable: agg}).toPandas()
    else:
        plot_df = df

    ax = plot_df.plot(x="Month", y=variable, kind=kind, **kwargs)
    ax.set_ylabel(ylabel)
    ax.set_xlabel(xlabel)
    ax.tick_params("x", rotation=45)
    if title is None:
        title = "{} distribution over time".format(variable)
    ax.set_title(title)
    if show:
        plt.show()
    return ax, plot_df


def eda_preparation(spark: SparkSession, table="idpos_transaction_fact") -> None:
    """Compute transaction table statistics for faster querying.

    Arguments:
        spark {SparkSession} -- SparkSession with access to required database.

    Keyword Arguments:
        table {str} -- Table name. Allows to analyse table that is not in currently used database.
    
    Returns:
        None
    """
    q = """
    ANALYZE TABLE
        {table}
    COMPUTE STATISTICS FOR COLUMNS
        transaction_datetm,
        consumer_id,
        store_id,
        prod_id,
        sales_amt,
        basket_id
    """.format(
        table=table
    )
    spark.sql(q)
