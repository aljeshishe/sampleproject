import pandas as pd
from pyspark.sql import DataFrame
import pyspark.sql.functions as pf
from pyspark.sql.types import StructType
from . import DATA_PATH


def load_demo_pos(filename="demoPOS.parquet") -> pd.DataFrame:
    return pd.read_parquet(DATA_PATH / filename)


def select_from_schema(df: DataFrame, schema: StructType) -> DataFrame:
    """Select needed fields from DataFrame, casting to the correct type.
    
    Parameters
    ----------
    df : DataFrame
        PySpark DataFrame that could be conformed to schema.
    schema : StructType
        Result schema.
    
    Returns
    -------
    DataFrame
        DataFrame with the provided schema.
    """
    names = {f.name: f.dataType for f in schema.fields}
    casts = []
    for name, data_type in names.items():
        col = pf.col(name).cast(data_type)
        casts.append(col)
    return df.select(*casts)
