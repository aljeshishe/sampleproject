import pandas as pd
import numpy as np
from typing import Callable, Union, List, Optional, Any, Iterable
from pyspark.sql import DataFrame
import pyspark.sql.functions as pf


def lmroll(
    x: np.ndarray,
    width: int,
    fun: Callable = np.mean,
    fill: str = "partial",
    align: str = "right",
    **kwargs
) -> np.ndarray:
    r"""Lorenz' fast implementation of a rolling function call.
    
    Applies a function on a moving window. Cuts time vs. \link[zoo]{rollapply`` by half.    
    Additional convenience functionality implemented.
    
    Parameters
    ----------
    x : np.ndarray
        The vector to roll over.
    width : int
        The window length to use.
    fun : Callable, optional
        The function to use to aggregate the vector values within the window, by default np.mean.
    fill : str, optional
        Defines what shall be done for the start/end of the vector not having a full window.
        ``NA`` or any other value outputs NaN for vector positions where not the full window is 
            available.
        ``partial`` outputs the function applied to the partial window.
        ``complete`` fills with the value of the first or last complete window value. 
                    This avoids additional lr()/na.locf calls to fill the gaps with last valid value
                    (except when you have filtered)
        By default ``partial``
    align : str, optional
        Window alignment when rolling throught the vector:
            right:  (default) The function-created value is written to the LAST cell of the window.
                      For time series, this means taking the HISTORY into account.
            left:   The function-created value is written to the FIRST cell of the window.
                      For time series, this means taking the FUTURE into account.
            center: Takes half the window left & half the window right into account.
    kwargs : dict
            Supply additional arguments for the fun.

    Returns
    -------
    np.ndarray
        The resulting vector; always same-sized as x.

    Raises
    ------
    ValueError
        If fill value not in the ("partial", "complete", "NA")
    ValueError
        If align value not in ("center", "right", "left")
    """
    lenX = len(x)
    if fill == "complete":
        partial = -1
    elif fill == "partial":
        partial = 1
    elif fill == "NA":
        partial = 0
    else:
        raise ValueError("Expected one of (complete, partial, NA) for fill parameter, got {}".format(fill))

    if align == "right":
        # right window, from history
        window = []
        for i in range(lenX):
            if i < width - 1:
                if partial == 1:
                    window.append(np.arange(i + 1))
                elif partial == -1:
                    window.append(np.arange(width))
                else:
                    window.append(np.nan)
            else:
                window.append(np.arange(i - width + 1, i + 1))
    elif align == "left":
        # left window, from history
        window = []
        for i in range(lenX):
            if i > lenX - width:
                if partial == 1:
                    window.append(np.arange(i, lenX))
                elif partial == -1:
                    window.append(np.arange(lenX - width, lenX))
                else:
                    window.append(np.nan)
            else:
                window.append(np.arange(i, i + width))
    elif align == "center":
        # center window, from history
        window = []
        for i in range(lenX):
            if i < width // 2:
                if partial == 1:
                    window.append(np.arange(i + width // 2 + 1))
                elif partial == -1:
                    window.append(np.arange(width))
                else:
                    window.append(np.nan)
            elif i > (lenX - width // 2 - 1):
                if partial == 1:
                    window.append(np.arange(i - np.ceil(width / 2).astype(np.int64) + 1, lenX))
                elif partial == -1:
                    window.append(np.arange(lenX - width, lenX))
                else:
                    window.append(np.nan)
            else:
                window.append(
                    np.arange(i - np.ceil(width / 2).astype(np.int64) + 1, i + width // 2 + 1)
                )
    else:
        raise ValueError("Expected align to be one of ['center', 'right', 'left'], got {}".format(align))

    res = np.empty_like(x, dtype=np.float)
    for i, idx in enumerate(window):
        if np.any(np.isnan(idx)):
            res[i] = np.nan
        else:
            res[i] = fun(x[idx], **kwargs)
    return res


def roll(
    df: pd.DataFrame,
    col: str,
    window: int,
    fun: Callable = np.mean,
    align: str = "right",
    fill: str = "partial",
    by: Optional[Union[List[str], str]] = None,
    **kwargs
) -> pd.Series:
    """Do Rolling Function computation for PEA.

    Kept for compatibility reasons, but maps to new lmRoll fast implementation.
    Translates the partial parameter into a fill for lmRoll.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with column to roll over and optional grouping keys.
    col : str
        Name of the column to roll over.
    window : int
        The window length in number of rows.
    fun : Callable, optional
        The function to apply, by default np.mean.
    align : str, optional
        The window alignment. By default 'right' is used. 
        Supported values: c('right', 'left', 'center').
    fill : str, optional
        Defines what should happen with partial windows at the beginning and end of the dataset. 
        Supported values: c(complete, partial, NA). Default = "partial".
    by : Optional[List[str], str], optional
        Optional grouping keys to apply rolling window function to subsets of data.

    Returns
    -------
    pd.Series
        Series aligned to df with rolling window calculations results.
    """
    roll = df
    if by is not None:
        roll = df.groupby(by, sort=False)
    res = roll[col].transform(
        lambda s: lmroll(s.values, min(window, len(s)), fun=fun, align=align, fill=fill, **kwargs)
    )
    return res


def lr(x: Union[pd.Series, np.ndarray], default_value: Any) -> np.ndarray:
    """Left/Right fill ``NA`` values in a vector
       
       Function that copy-forward / copy-back values to fill ``NA`` values within the
       provided vector (in that order). If afterwards, there are still ``NA`` values
       remaining, replaces them with the provided ``defaultValue``
       @note Try avoid using this together with lmRoll, but instead
       use ``fill=complete``!
    
    Parameters
    ----------
    x : Union[pd.Series, np.ndarray]
        The vector where np.nan values shall be filled.
    default_value : Any
        Used if there are no non-NA value.
    
    Returns
    -------
    np.ndarray
        Returns the vector ``x`` fully filled without any ``NA`` values.
    """
    if isinstance(x, pd.Series):
        x = x.values
    data = ~pd.isnull(x) * np.arange(len(x))
    y = pd.Series(data=data).cummax().values
    if np.any(y != 0) and pd.isnull(x[0]):
        y[y == 0] = y[y != 0][0]
    return np.where(pd.isnull(x[y]), default_value, x[y])


def rleid(*args: Union[pd.Series, np.ndarray], fill_value: int = -1) -> pd.Series:
    """Running length encoding/enumeration.

    A convenience function for generating a run-length type id column to be used in grouping
    operations. It accepts pd.Series and NumPy ndarrays as input.
    
    Parameters
    ----------
    fill_value : int, optional
        Fill value for np.nan in arguments, by default -1.
    
    Returns
    -------
    pd.Series
        Enumerated sequences of consecutive values.
    """
    df = pd.concat(args, axis=1)
    df = df.fillna(fill_value)
    diff = df != df.shift()
    diff = diff.max(axis=1)
    return diff.cumsum()


def melt(
    df: DataFrame,
    id_vars: Iterable[str],
    value_vars: Iterable[str],
    var_name: str = "variable",
    value_name: str = "value",
) -> DataFrame:
    """Convert DataFrame from `wide` format to `long` format.
    
    Idea is to represent whole set of columns as id_columns (stays as is), variable (contains name
    of the column, or key) and value (contains value of corresponding key).

    
    Arguments:
        df {DataFrame} -- Spark DataFrame.
        id_vars {Iterable[str]} -- List of column names to leave as is.
        value_vars {Iterable[str]} -- List of columns that should be included.
        The rest is discarded.
    
    Keyword Arguments:
        var_name {str} -- Name of the key column in resulting DataFrame (default: {"variable"}).
        value_name {str} -- Name of the key column in resulting DataFrame (default: {"value"}).
    
    Returns:
        DataFrame -- `Long` form of original DataFrame.
    """

    # Create array<struct<variable: str, value: ...>>
    struct = [pf.struct(pf.lit(c).alias(var_name), pf.col(c).alias(value_name)) for c in value_vars]
    _vars_and_vals = pf.array(*struct)

    # Add to the DataFrame and explode
    _tmp = df.withColumn("_vars_and_vals", pf.explode(_vars_and_vals))

    cols = id_vars + [pf.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]]
    return _tmp.select(*cols)
