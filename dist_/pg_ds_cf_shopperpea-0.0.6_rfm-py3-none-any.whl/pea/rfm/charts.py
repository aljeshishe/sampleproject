import plotly.graph_objects as go


def avg_purch_cycle_bars(df):
    df = df.toPandas().set_index("time_flag").T
    fig = go.Figure([go.Bar(x=df.index, y=df[col], name=col) for col in df.columns])
    fig.update_layout(barmode="group")
    fig.update_traces(width=0.15)
    return fig


def sum_sales_amount_bars(df):
    df = df.toPandas().set_index("time_flag")
    fig = go.Figure([go.Bar(x=df.index, y=df[col], name=col) for col in df.columns])
    fig.update_layout(barmode="stack", xaxis={"categoryorder": "category ascending"}, template="simple_white")
    fig.update_traces(width=0.15)
    return fig


def classes_bars(df):
    df = df.groupby("prod_brand").pivot("class").count().fillna(0,
                                                                subset=["Dealseeker", "Disappeared", "New Loyal",
                                                                        "Notinterested", "Subsidized"])
    df = df.toPandas().set_index("prod_brand")
    fig = go.Figure([go.Bar(x=df.index, y=df[col], name=col) for col in df.columns])
    fig.update_layout(barmode="relative", xaxis={"categoryorder": "category ascending"}, template="simple_white",
                      barnorm="percent", yaxis_autorange=True)
    fig.update_traces(width=0.15)
    return fig
