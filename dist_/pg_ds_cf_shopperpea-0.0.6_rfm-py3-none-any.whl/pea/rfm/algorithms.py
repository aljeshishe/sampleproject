from pyspark.sql import functions as F
from pyspark.sql import types as T


def _add_transaction_date_col(df):
    return df.withColumn("transaction_date", F.col("transaction_datetm").cast(T.DateType()))


def _agg_on_days(df):
    # when customer buys several items, they could be in separate transactions
    # We need to agg them in single transactions
    cols = df.columns
    cols.remove("sales_amt")
    cols.remove("sales_qty")
    cols.remove("discount_pct")
    cols.remove("unit_price_amt")
    cols.remove("discount_amt")
    cols.remove("transaction_datetm")
    df = df.groupBy(cols).agg(F.sum("sales_amt").alias("sales_amt"),
                              F.sum("sales_qty").alias("sales_qty"),
                              F.sum("discount_amt").alias("discount_amt"),
                              F.avg("discount_pct").alias("discount_pct"),
                              F.avg("unit_price_amt").alias("unit_price_amt"))
    return df


def _add_recency_days_col(df):
    # add RecencyDays column(days before/after promo)
    end_date = df.agg({"transaction_date": "max"}).collect()[0][0]
    df = df.withColumn("end_date", F.lit(end_date)).withColumn("RecencyDays",
                                                               F.expr("datediff(end_date, transaction_date)"))
    return df


def _only_promo(df):
    # find only promo transactions and filterout promos which we are not interested in
    df = df.where("promo_flag=true") \
        .select("consumer_id", "prod_id", "transaction_date", "promo_type") \
        .drop_duplicates() \
        .withColumnRenamed("transaction_date", "transaction_date_promo") \
        .withColumnRenamed("promo_type", "promo_type_promo")
    return df


def _join_with_promo(df, promo_df):
    # Prepare all possibe pairs: regular transaction-promo transaction
    return df.join(promo_df, "consumer_id", "inner")


def _add_time_flag_col(df):
    return df.withColumn("time_flag", F.when(F.col("transaction_date") > F.col("transaction_date_promo"), "After"). \
                         when(F.col("transaction_date") < F.col("transaction_date_promo"), "Before"). \
                         otherwise("Same")
                         )


def _add_days_from_promo_col(df):
    return df.withColumn("DaysFromPromo", F.expr("abs(datediff(transaction_date_promo, transaction_date))"))


def _agg(df, groupby_col, agg):
    if agg == "sum_sales_amount":
        agg = F.sum("sales_amt").alias("Monetary")
    elif agg == "avg_purch_cycle":
        rfm_cols = {"consumer_id", "transaction_date_promo", "time_flag", "prod_gtin", "unit_price_amt", "promo_flag",
                    "discount_amt"}
        rfm_cols.add(groupby_col)
        df = df.groupby(list(rfm_cols)) \
            .agg(F.min("RecencyDays").alias("Recency"), \
                 F.min("DaysFromPromo").alias("DaysFromPromo"), \
                 F.max("DaysFromPromo").alias("TimeSpan"), \
                 F.countDistinct("transaction_date").alias("Frequency"), \
                 F.sum("sales_amt").alias("Monetary"))
        df = df.withColumn("purch_cycle", F.expr("TimeSpan / Frequency")).withColumn("yearly_spend",
                                                                                     F.expr("Monetary/TimeSpan*365"))
        agg = F.avg("purch_cycle")

    df = df.groupby("time_flag").pivot(groupby_col).agg(agg).where("time_flag in ('Before', 'After')")
    return df


def before_after(df, promo_filter, grouping_filter, groupby_col, agg, days_from_promo=365):
    df = _add_transaction_date_col(df)
    df.persist()
    df = _agg_on_days(df)
    df.persist()
    df = _add_recency_days_col(df)
    df.persist()
    promo_df = _only_promo(df)
    if promo_filter:
        promo_df = promo_df.where(promo_filter)
    df = _join_with_promo(df, promo_df)
    df.persist()
    df = _add_time_flag_col(df)
    df.persist()
    df = _add_days_from_promo_col(df)
    df.persist()

    # We are not interested in transaction more than year before/after transaction
    df = df.where(f"DaysFromPromo<{days_from_promo}")
    df.persist()
    if grouping_filter:
        df = df.where(grouping_filter)
    df = _agg(df, groupby_col, agg)
    df.persist()
    return df

