from pyspark.sql import functions as F

from pea.rfm.algorithms import _add_transaction_date_col, _agg_on_days, _add_recency_days_col, _only_promo


def _add_trans_class_col(df):
    df = df.withColumn("trans_class",
                       F.when(F.col("transaction_date_promo").isNull(), "never_bought")
                       .when(F.col("transaction_date_promo") > F.col("transaction_date"), "will_buy")
                       .when(F.col("transaction_date_promo") == F.col("transaction_date"), "bought_promo")
                       .when(F.col("transaction_date_promo") < F.col("transaction_date"), "has_bought")
                       )
    return df


def _count_trans_class(df, grouping_cols):
    df = df.groupby(grouping_cols + ["trans_class"]).count()
    df.persist()
    df = df.groupby(grouping_cols).pivot("trans_class").sum("count").fillna(0, subset=["never_bought", "will_buy",
                                                                                       "bought_promo", "has_bought"])
    df.persist()
    return df


def _add_class_col(df):
    df = df.withColumn("class",
                       F.when(F.col("bought_promo") == 0, "Notinterested")
                       .when((F.col("has_bought") == 0) & (F.col("will_buy") == 0), "Dealseeker")
                       .when((F.col("has_bought") == 0) & (F.col("will_buy") > 0), "New Loyal")
                       .when((F.col("has_bought") > 0) & (F.col("will_buy") == 0), "Disappeared")
                       .when((F.col("has_bought") > 0) & (F.col("will_buy") > 0), "Subsidized")
                       .otherwise("Other")
                       )
    return df


def _count_classes(df, grouping_cols):
    cols = grouping_cols[:]
    cols.remove('consumer_id')
    df = df.groupby(cols + ["class"]).count()
    df.persist()
    return df


def promo_event_window(df, promo_filter=''):
    df = _add_transaction_date_col(df)
    df = _agg_on_days(df)
    df = _add_recency_days_col(df)
    promo_df = _only_promo(df)
    if promo_filter:
        promo_df = promo_df.where(promo_filter)
    df = df.join(promo_df, ["prod_id", "consumer_id"], "left")
    df = _add_trans_class_col(df)

    grouping_cols = ["consumer_id", "prod_id", "prod_gtin", "prod_name", "transaction_date_promo", "promo_type",
                     "prod_brand", "prod_subcategory", "prod_category"]
    df = _count_trans_class(df, grouping_cols)
    classes = _add_class_col(df)
    classes_counts = _count_classes(classes, grouping_cols)

    return classes, classes_counts
