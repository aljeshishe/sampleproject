from abc import ABC, abstractmethod
from contextlib import contextmanager

PASS = 'PASS'
INFO = 'INFO'
WARN = 'WARN'
FAIL = 'FAIL'


class OutputBase(ABC):
    @abstractmethod
    def message(self, status, message, prefixes):
        pass

    @abstractmethod
    def with_prefix(self, prefix):
        return OutputBase()

    @abstractmethod
    def check_df_is_empty(self, status, df, message):
        pass

    @abstractmethod
    def check_is_true(self, value, status, message, fail_postfix=''):
        pass

    @abstractmethod
    def check_no_exception(self, type, status, message, fail_postfix=''):
        pass


class Output(OutputBase):
    def __init__(self, samples=5, show_pass=False, prefix=''):
        self.samples = samples
        self.show_pass = show_pass
        self.prefixes = []
        if prefix:
            self.prefixes.append(prefix)

    @contextmanager
    def with_prefix(self, prefix):
        self.prefixes.append(prefix)
        yield self
        self.prefixes.pop()

    def check_df_is_empty(self, status, df, message):
        count = df.count()
        self.check_is_true(value=count == 0,
                           status=status,
                           message=message,
                           fail_postfix='found {} samples:\n{}'.format(count, self._as_string(df, n=self.samples)))

    def check_is_true(self, value, status, message, fail_postfix=''):
        if not value:
            if fail_postfix:
                message = '{}, {}'.format(message, fail_postfix)
            self.message(status=status, message=message, prefixes=self.prefixes)
            return

        if self.show_pass:
            self.message(status=PASS, message=message, prefixes=self.prefixes)

    @contextmanager
    def check_no_exception(self, type, status, message, fail_postfix=''):
        raised = False
        try:
            yield
        except Exception as e:
            if isinstance(e, type):
                raised = True

        self.check_is_true(value=not raised, status=status, message=message, fail_postfix=fail_postfix)

    @staticmethod
    def _as_string(df, n=5, truncate=True, vertical=False):
        if isinstance(truncate, bool) and truncate:
            return df._jdf.showString(n, 20, vertical)
        else:
            return df._jdf.showString(n, int(truncate), vertical)


class ConsoleOutput(Output):
    def message(self, status, message, prefixes):
        print('{}{}: {}'.format(''.join(prefixes), status, message))
