from collections import OrderedDict
from typing import Dict

import pyspark.sql.functions as pf
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType

from .output import FAIL, WARN, INFO, Output

KEY_COLUMNS = 1


def _key_columns(schema):
    return [field.name for field in schema if field.metadata and field.metadata['key']]


def _distinct(columns):
    return list(OrderedDict.fromkeys(columns))


class TableRule:
    """This is a base class for table validation rule.
    If you want to add a new validation rule:
        1. Inherit it with a new Rule class
        2. Implement your validation logic inside validate method of the new Rule class
        3. Instantiate new Rule class in a rule set
    """
    def validate(self, output: Output, df: DataFrame, schema: StructType):
        """This method is called during table validation.
        It should validate dataframe using it's own logic and provided schema and output results to output object.

        Parameters
        ----------
        output
            all results should be outputed to output object
        df
            Dataframe to validate
        schema
            Expected schema from rule set
        """
        pass

    def __str__(self):
        return self.__class__.__name__

    __repr__ = __str__


class DbRule:
    """This is a base class for database validation rule.
    If you want to add a new validation rule follow same process as with TableRule
    """
    def validate(self, output, dataframes):
        """This method is called during database validation.
        It should validate provided dataframes using it's own logic and output results to output object.

        Parameters
        ----------
        output
            all results should be outputed to output object
        dataframes
            Dict of ``{'table name': dataframe}``
        """
        pass

    def __str__(self):
        return self.__class__.__name__

    __repr__ = __str__


class ValidateSchemaRule(TableRule):
    """This rule performs schema validation
    This rule compares actual schema(from dataframe) and expected schema(from 'schema' field of rule set).
    Following checks are done:
    1. If actual schema has unexpected columns, there will be FAIL output
    2. If actual schema missing columns, there will be FAIL output
    3. If actual schema column type differs from expected schema, there will be FAIL output
    4. If actual schema column nullable flag differs from expected schema, there will be WARN output
    """
    def validate(self, output, df, schema):
        self._validate(output=output, actual_schema=df.schema, expected_schema=schema)

    @staticmethod
    def _validate(output, actual_schema, expected_schema):
        # All mandatory columns exist and are of right type, nullable
        # sorted used for reproducibility
        actual_names = set(actual_schema.names)
        expected_names = set(expected_schema.names)

        unexpected_names = actual_names - expected_names
        output.check_is_true(not unexpected_names,
                             status=FAIL,
                             message='Expected no unexpected columns',
                             fail_postfix='found unexpected columns ({})'.format(' '.join(sorted(unexpected_names))))

        missing_names = expected_names - actual_names
        output.check_is_true(not missing_names,
                             status=FAIL,
                             message='Expected no missing columns',
                             fail_postfix='found missing columns: ({})'.format(' '.join(sorted(missing_names))))

        similar_names = expected_names.intersection(actual_names)
        actual_schema_dict = {field.name: field for field in actual_schema}
        expected_schema_dict = {field.name: field for field in expected_schema}
        for name in sorted(similar_names):
            if actual_schema_dict[name] == expected_schema_dict[name]:
                continue
            actual_type = actual_schema_dict[name].dataType
            expected_type = expected_schema_dict[name].dataType
            output.check_is_true(actual_type == expected_type,
                                 status=FAIL,
                                 message='Expected column "{}" to be "{}"'.format(name, expected_type),
                                 fail_postfix='found "{}"'.format(actual_type))
            actual_nullable = actual_schema_dict[name].nullable
            expected_nullable = expected_schema_dict[name].nullable
            output.check_is_true(actual_nullable == expected_nullable,
                                 status=WARN,
                                 message='Expected column "{}" nullable to be "{}"'.format(name, expected_nullable),
                                 fail_postfix='found "{}"'.format(actual_nullable))


class NoNegativesRule(TableRule):
    """This rule checks that column(s) has no negative values
    """

    def __init__(self, columns, status=FAIL):
        self.columns = columns
        self.status = status

    def validate(self, output, df, schema):
        columns = _key_columns(schema) if self.columns == KEY_COLUMNS else self.columns

        key_columns = _key_columns(schema)
        for column in columns:
            negatives_df = df.select(_distinct(key_columns + [column])).where(df[column] < 0)
            output.check_df_is_empty(status=self.status,
                                     df=negatives_df,
                                     message='Expected no negative values in "{}" column'.format(column))


class NoDuplicatesRule(TableRule):
    """This rule validates that there are no duplicate values in specified column(s)
    """
    def __init__(self, columns, status=FAIL):
        self.columns = columns
        self.status = status

    def validate(self, output, df, schema):
        columns = _key_columns(schema) if self.columns == KEY_COLUMNS else self.columns

        # groupby requires list not tuple
        duplicates_df = df.groupby(list(columns)).count().where('count > 1').sort('count', ascending=False)
        output.check_df_is_empty(status=self.status,
                                 df=duplicates_df,
                                 message='Expected no duplicates found for columns({})'.format(
                                     ' '.join(columns)))


class NoIncorrectDatesRule(TableRule):
    """This rule validates that there are no values with incorrect dates in specified column(s).
    Incorrect dates are dates not from interval (start_date, end_date).
    """
    def __init__(self, columns, start_date, end_date, status=FAIL):
        """
        Parameters
        ----------
        columns
            Columns to validate

        start_date
            Start date of valid date interval

        end_date
            End date of valid date interval

        status
            Status to report

        """
        self.columns = columns
        self.start_date = start_date
        self.end_date = end_date
        self.status = status

    def validate(self, output, df, schema):
        columns = _key_columns(schema) if self.columns == KEY_COLUMNS else self.columns

        key_columns = _key_columns(schema)
        for column in columns:
            invalid_date_df = df.select(_distinct(key_columns + [column])). \
                where((pf.col(column) < self.start_date) | (pf.col(column) > self.end_date))
            output.check_df_is_empty(status=self.status,
                                     df=invalid_date_df,
                                     message='Expected no invalid values(not between [{}, {}]) in "{}" column '.format(
                                         self.start_date,
                                         self.end_date,
                                         column))


class NoNullsOrNansRule(TableRule):
    """This rule validates that there are no Null or Nan values.
        If columns specified in `columns` argument violate rule,
        they will be reported with status specified in `status` argument.
        All other rule violations will be reported with INFO status;
    """
    def __init__(self, columns=None, status=FAIL):
        """
        Parameters
        ----------
        columns
            Columns to validate

        status
            Status to report

        """
        self.columns = columns or {}
        self.status = status

    def validate(self, output, df, schema):
        key_columns = _key_columns(schema)
        columns = dict(df.dtypes)
        for column in columns.keys():
            cond = df[column].isNull()
            if columns[column] in ('float', 'double'):
                cond |= pf.isnan(df[column])

            nones_and_nans = df.select(_distinct(key_columns + [column])).filter(cond)
            output.check_df_is_empty(status=self.status if column in self.columns else INFO,
                                     df=nones_and_nans,
                                     message='Expected no Null or Nan values in "{}" column expected'.format(column))


class FullJoinRule(DbRule):
    """This rule validates that specified tables could be joined on specified column(s) and there
        are no values which could not be joined from left/right side.
    """
    def __init__(self, left_table, right_table, columns, status=FAIL):
        """
        Parameters
        ----------
        left_table
            Left table for join

        right_table
            Right table for join

        columns
            columns to join data on

        status
            status

        """

        self.left_table = left_table
        self.right_table = right_table
        self.columns = columns
        self.status = status

    def validate(self, output, dataframes):
        with output.with_prefix('{}-{} join: '.format(self.left_table, self.right_table)) as output:
            self._validate(output=output, dataframes=dataframes)

    def _validate(self, output, dataframes):
        left_df = dataframes.get(self.left_table)
        right_df = dataframes.get(self.right_table)
        output.check_is_true(left_df,
                             status=WARN,
                             message='Expected "{}" table to exist(or dataframe to be provided) for join validation'.format(
                                 self.left_table))

        output.check_is_true(right_df,
                             status=WARN,
                             message='Expected "{}" table to exist(or dataframe to be provided) for join validation'.format(
                                 self.right_table))
        if left_df is None or right_df is None:
            return

        left_df = left_df.select(self.columns).distinct()
        right_df = right_df.select(self.columns).distinct()

        tl = left_df.alias('tl')
        tr = right_df.alias('tr')

        join_cond = pf.lit(True)
        left_cond = pf.lit(False)
        right_cond = pf.lit(False)
        for col in self.columns:
            join_cond &= (tl[col] == tr[col])
            left_cond |= tl[col].isNull()
            right_cond |= tr[col].isNull()

        join = tl.join(tr, join_cond, how='full')
        non_joinable_right_df = join.filter(left_cond)
        message_template = 'Expected no rows from "{}" can not join with "{}" on ({}) columns'
        output.check_df_is_empty(status=self.status,
                                 df=non_joinable_right_df,
                                 message=message_template.format(self.left_table, self.right_table,
                                                                 ' '.join(self.columns)))

        non_joinable_left_df = join.filter(right_cond)
        output.check_df_is_empty(status=self.status,
                                 df=non_joinable_left_df,
                                 message=message_template.format(self.right_table, self.left_table,
                                                                 ' '.join(self.columns)))
