import os
from datetime import datetime, date
from typing import Dict, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructField, DoubleType, StructType, StringType, BooleanType
from pyspark.sql.utils import AnalysisException
import pyspark.sql.types as pt
import pyspark.sql.functions as pf

from .output import ConsoleOutput, FAIL, WARN, INFO, Output
from .rule import NoNegativesRule, NoDuplicatesRule, NoIncorrectDatesRule, NoNullsOrNansRule, FullJoinRule, \
    ValidateSchemaRule, KEY_COLUMNS


class Validator:
    """
    Validator is used for validation schema and data inside tables/dataframes.
    Validation is process of applying set of rules on schema and data one by one.

    Use validate_db to validate existing database.
    Use validate_dataframes to validate dataframes read from other sources(i.e. files)
    Use tables to see what tables are going to be validated.
    You may modify Validator.rules to affect rules to be applied.

    Each rule can generate one or several outputs (FAIL/WARN/INFO/PASS). All outputs are collected by output object.
    Here are examples of outputs:
        idpos_transaction_fact-idpos_consumer_dim join: PASS: Expected no rows from "idpos_transaction_fact" can not join with "idpos_consumer_dim" on (consumer_id retailer_name) columns
        idpos_transaction_fact-idpos_consumer_dim join: FAIL: Expected no rows from "idpos_consumer_dim" can not join with "idpos_transaction_fact" on (consumer_id retailer_name) columns. Found 810501 samples:
        +------------+-------------+-----------+-------------+
        | consumer_id|retailer_name|consumer_id|retailer_name|
        +------------+-------------+-----------+-------------+
        |415101009812| DIMAR S.P.A.|       null|         null|
        |415101010412| DIMAR S.P.A.|       null|         null|
        |415101011228| DIMAR S.P.A.|       null|         null|
        |415101048057| DIMAR S.P.A.|       null|         null|
        |415101054744| DIMAR S.P.A.|       null|         null|
        |415101073455| DIMAR S.P.A.|       null|         null|
        |415101076418| DIMAR S.P.A.|       null|         null|
        |415101077927| DIMAR S.P.A.|       null|         null|
        |415101103206| DIMAR S.P.A.|       null|         null|
        |415101149778| DIMAR S.P.A.|       null|         null|
        +------------+-------------+-----------+-------------+
        only showing top 10 rows

    Here you may see:
        validated table(tables): idpos_transaction_fact-idpos_consumer_dim join
        status: PASS, FAIL
        expected: Expected no rows from "idpos_consumer_dim" can not join with "idpos_transaction_fact" on (consumer_id retailer_name) columns.
        actual:
            Found 810501 samples:
            +------------+-------------+-----------+-------------+
            | consumer_id|retailer_name|consumer_id|retailer_name|
            +------------+-------------+-----------+-------------+
            |415101009812| DIMAR S.P.A.|       null|         null|
            |415101010412| DIMAR S.P.A.|       null|         null|
        ...
    If you need to customize output, see output.py for details.

    Rules is a dict of following structure:
    {
        'tables': {
            '<table_name>': {
                'schema': <StructType describing schema>
                'rules': [<table rules>...]
            }
            ...
        },
        'rule': [<database rules>...]
    }
    Table rules are applied to a single table and could be used to validate schema, column values, etc.
    Database rules are applied to all tables and could be used to validate that tables are joinable.
    You may find more info in rule.py file.

    """
    default_rules = {
        'tables': {
            'idpos_transaction_fact': {
                'schema': StructType()
                    .add("basket_id", pt.StringType(), False, dict(key=True))
                    .add("consumer_id", pt.StringType(), False, dict(key=True))
                    .add("store_id", pt.StringType(), False, dict(key=True))
                    .add("counter_id", pt.StringType(), False, dict(key=True))
                    .add("retailer_name", pt.StringType(), False, dict(key=True))
                    .add("transaction_datetm", pt.TimestampType(), False, dict(key=True))
                    .add("prod_id", pt.StringType(), False, dict(key=True))
                    .add("prod_category", pt.StringType(), True)
                    .add("prod_subcategory", pt.StringType(), True)
                    .add("prod_manufacturer", pt.StringType(), True)
                    .add("prod_brand", pt.StringType(), True)
                    .add("prod_level", pt.StringType(), True)
                    .add("prod_pg_flag", pt.BooleanType(), True)
                    .add("prod_name", pt.StringType(), True)
                    .add("prod_gtin", pt.StringType(), True)
                    .add("sales_qty", pt.DoubleType(), True)
                    .add("sales_amt", pt.DoubleType(), True)
                    .add("unit_price_amt", pt.DoubleType(), True)
                    .add("discount_amt", pt.DoubleType(), True)
                    .add("discount_pct", pt.DoubleType(), True)
                    .add("promo_flag", pt.BooleanType(), True)
                    .add("promo_type", pt.StringType(), True),
                'rules': [
                    ValidateSchemaRule(),
                    NoNegativesRule(columns=['sales_qty', 'sales_amt'], status=WARN),
                    NoNegativesRule(columns=['unit_price_amt']),
                    NoNullsOrNansRule(columns=['sales_qty', 'sales_amt', 'discount_amt', 'discount_pct',
                                               'unit_price_amt', 'promo_flag']),
                    NoIncorrectDatesRule(columns=['transaction_datetm'],
                                         start_date=datetime(2000, 1, 1),
                                         end_date=datetime.today()),
                    NoDuplicatesRule(columns=KEY_COLUMNS),
                ]
            },
            'idpos_transaction_detail_fact': {
                'schema': StructType()
                    .add("basket_id", pt.StringType(), False, dict(key=True))
                    .add("prod_id", pt.StringType(), False, dict(key=True))
                    .add("retailer_name", pt.StringType(), False, dict(key=True))
                    .add("store_id", pt.StringType(), False, dict(key=True))
                    .add("counter_id", pt.StringType(), False, dict(key=True))
                    .add("basket_attr_key", pt.StringType(), False)
                    .add("basket_attr_val", pt.StringType(), False)
                    .add("transaction_datetm", pt.TimestampType(), False, dict(key=True)),
                'rules': [
                    ValidateSchemaRule(),
                    NoNullsOrNansRule(),
                    # NoDuplicatesRule(columns=KEY_COLUMNS),
                ]
            },
            'idpos_consumer_dim': {
                'schema': StructType()
                    .add("consumer_id", pt.StringType(), False)
                    .add("retailer_name", pt.StringType(), False)
                    .add("consumer_attr_key", pt.StringType(), False)
                    .add("consumer_attr_val", pt.StringType(), True)
                    .add("last_modified_datetm", pt.TimestampType(), False),
                'rules': [
                    ValidateSchemaRule(),
                    NoNullsOrNansRule(),
                ],
            },
            'idpos_store_dim': {
                'schema': StructType()
                    .add("store_id", pt.StringType(), False)
                    .add("retailer_name", pt.StringType(), False)
                    .add("store_attr_key", pt.StringType(), False)
                    .add("store_attr_val", pt.StringType(), False)
                    .add("last_modified_datetm", pt.StringType(), False),
                'rules': [
                    ValidateSchemaRule(),
                    NoNullsOrNansRule(),
                ],
            },
            'idpos_prod_dim': {
                'schema': StructType()
                    .add("prod_id", pt.StringType(), False)
                    .add("retailer_name", pt.StringType(), False)
                    .add("prod_attr_key", pt.StringType(), False)
                    .add("prod_attr_val", pt.StringType(), False)
                    .add("last_modified_datetm", pt.TimestampType(), False),
                'rules': [
                    ValidateSchemaRule(),
                    NoNullsOrNansRule(),
                ],
            },
        },
        'rules': [
            # FullJoinRule(left_table='idpos_transaction_fact', right_table='idpos_transaction_detail_fact',
            #              columns=['basket_id', 'prod_id', 'retailer_name']),
            FullJoinRule(left_table='idpos_transaction_fact', right_table='idpos_consumer_dim',
                         columns=['consumer_id', 'retailer_name']),
            FullJoinRule(left_table='idpos_transaction_fact', right_table='idpos_store_dim',
                         columns=['store_id', 'retailer_name']),
            FullJoinRule(left_table='idpos_transaction_fact', right_table='idpos_prod_dim',
                         columns=['prod_id', 'retailer_name']),
        ]

    }

    def __init__(self, rules=None):
        self.rules = rules or self.default_rules

    @property
    def tables(self):
        """Returns tables are to be validated
        """
        return self.rules['tables'].keys()

    def validate_db(self, spark: SparkSession, db_name: str, output: Optional[Output] = None) -> Output:
        """Validate whole database

        Parameters
        ----------
        spark : SparkSession
            Spark session to execute validation
        db_name : str
            Name database to validate
        output
            Output is used to collect all outputs of all checks.
            If not specified ConsoleOutput with default params will be created

        Returns
        -------
        output
            Method will return passed or created output
        """
        if output is None:
            output = ConsoleOutput()

        dataframes = {}
        for name in self.tables:
            full_table_name = '{}.{}'.format(db_name, name)
            with output.check_no_exception(type=AnalysisException,
                                           status=FAIL,
                                           message='Expected "{}" table to exist'.format(full_table_name),
                                           fail_postfix='no table found'):
                dataframes[name] = spark.read.table(full_table_name)
        self.validate_dataframes(**dataframes, output=output)

        return output

    def validate_dataframes(self, output: Optional[Output] = None,
                            **dataframes: Dict[str, DataFrame]) -> Output:
        """Validate set of dataframes

        Example: validate_dataframes(idpos_transaction_fact=spark.read.table('p_nas_italy_dimar.idpos_transaction_fact'))

        Parameters
        ----------
        output
            Output is used to collect outputs of all checks.
            If not specified ConsoleOutput with default params will be created

        dataframes : dict
            Dict of ``{'table name': dataframe}`` to validate.
            You may use Validator.tables to get expected tables.
            It's ok if you provide incomplete set of dataframes. In this case only possible checks will be performed.
            Other checks will warn you that they are impossible to perform.

        Returns
        -------
        output :
            Method will return passed or created output
        """
        if output is None:
            output = ConsoleOutput()

        for name, df in dataframes.items():
            table_info = self.rules['tables'][name]
            for rule in table_info['rules']:
                # print(rule)  # TODO remove
                with output.with_prefix(name + ': ') as output:
                    rule.validate(output=output, df=df, schema=table_info['schema'])

        for rule in self.rules['rules']:
            rule.validate(output=output, dataframes=dataframes)

        return output
