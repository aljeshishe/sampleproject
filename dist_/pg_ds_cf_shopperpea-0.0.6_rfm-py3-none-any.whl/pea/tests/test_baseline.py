import pea
from pandas.testing import assert_frame_equal
import numpy as np


def test_prep_weekly_data_for_posbsln(demoPOS, prepped_weekly_pos):
    prepped_pos = pea.prep_weekly_pos_for_pea(
        demoPOS, Threshold_lowSales=100, CONF_ProdLaunch=-1, debug=False
    )
    assert_frame_equal(prepped_weekly_pos, prepped_pos)


def test_calculate_ref_price(prepped_weekly_pos, ref_price):
    calc_ref_price = pea.calculate_ref_price(
        prepped_weekly_pos,
        CONF_RefPrice_Window=16,
        Threshold_price_discount=5,
        Threshold_lowSales=100,
        CONF_RefPrice_Logic=4,
        debug=False,
    )
    assert_frame_equal(ref_price, calc_ref_price)


def test_calculate_non_price_promo_peaks(ref_price, promo_peaks):
    df = pea.calculate_non_price_promo_peaks(
        ref_price,
        CONF_NonPrice_Window=13,
        Threshold_nonprice_promo=1.5,
        CONF_NonPrice_Adjust=False,
    )
    assert_frame_equal(promo_peaks, df)


def test_lr_first_nan_replaced():
    x = np.array([np.nan, 1, 2])
    act = pea.lr(x, 0)
    exp = np.array([1, 1, 2])
    np.testing.assert_array_equal(exp, act)


def test_lr_no_nan_replacing():
    x = np.array([1, 2])
    act = pea.lr(x, 0)
    exp = np.array([1, 2])
    np.testing.assert_array_equal(exp, act)
