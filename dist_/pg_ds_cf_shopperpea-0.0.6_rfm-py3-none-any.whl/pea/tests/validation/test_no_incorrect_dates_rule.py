from datetime import datetime, timedelta

from pyspark.sql.types import StructType, TimestampType

from pea.tests.validation.conftest import ListOutput
from pea.validation.rule import NoIncorrectDatesRule


class TestNoIncorrectDatesRule:

    def test_no_fails(self, spark):
        schema = StructType(). \
            add("col1", TimestampType(), False)

        start = datetime(2000, 1, 1)
        end = datetime.today()
        data = [[start], [end]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoIncorrectDatesRule(['col1'], start, end). \
            validate(output=output, df=df, schema=schema)
        output.assert_equal('')

    def test_fails(self, spark):
        schema = StructType(). \
            add("col1", TimestampType(), False)

        start = datetime(2000, 1, 1)
        end = datetime(2001, 1, 1, 1, 1)
        data = [
            [start - timedelta(hours=1)],  # FAIL: outside interval
            [start],  # PASS: as valid interval is strict
            [start + timedelta(hours=1)],  # PASS: as inside interval
            [end - timedelta(hours=1)],  # PASS: as inside interval
            [end],  # PASS: as valid interval is strict
            [end + timedelta(hours=1)]  # FAIL: outside interval
        ]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoIncorrectDatesRule(['col1'], start, end). \
            validate(output=output, df=df, schema=schema)
        expected = '''
FAIL Expected no invalid values(not between [2000-01-01 00:00:00, 2001-01-01 01:01:00]) in "col1" column , found 2 samples:
+-------------------+
|               col1|
+-------------------+
|1999-12-31 23:00:00|
|2001-01-01 02:01:00|
+-------------------+
'''
        output.assert_equal(expected)