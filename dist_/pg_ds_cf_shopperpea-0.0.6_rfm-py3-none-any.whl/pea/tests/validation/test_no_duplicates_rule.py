from pyspark.sql.types import StructType, IntegerType

from pea.tests.validation.conftest import ListOutput
from pea.validation.rule import NoDuplicatesRule


class TestNoDuplicatesRule:

    def test_no_fails(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [4, 5, 6]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoDuplicatesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        assert output == []

    def test_duplicate_in_one_column(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [1, 5, 6]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoDuplicatesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        assert output == []

    def test_duplicates_in_both_columns(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [1, 2, 6],
                [1, 5, 6]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoDuplicatesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        expected = '''
FAIL Expected no duplicates found for columns(col1 col2), found 1 samples:
+----+----+-----+
|col1|col2|count|
+----+----+-----+
|   1|   2|    2|
+----+----+-----+
'''
        output.assert_equal(expected)