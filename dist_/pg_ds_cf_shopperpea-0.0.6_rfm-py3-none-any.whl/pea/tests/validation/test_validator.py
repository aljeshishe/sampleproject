from unittest import mock

from mock import call
from pyspark.sql.types import StructType, StringType
from pyspark.sql.utils import AnalysisException

from pea.tests.validation.conftest import ListOutput
from pea.validation import Validator, Output


def test_complex_validation():
    rules = {
        'tables': {
            'table1': {
                'schema': StructType().add("store_id", StringType(), False),
                'rules': [
                    mock.MagicMock(),
                    mock.MagicMock(),
                ],
            },
            'table2': {
                'schema': StructType().add("store_id", StringType(), False),
                'rules': [mock.MagicMock(), mock.MagicMock(),
                          ],
            },
        },
        'rules': [
            mock.MagicMock(),
            mock.MagicMock(),
        ]

    }

    spark = mock.MagicMock()
    df = spark.read.table.return_value = mock.MagicMock()

    validator = Validator(rules=rules)
    assert validator.tables ==  {'table1', 'table2'}
    output = validator.validate_db(spark=spark, db_name='db_name')
    assert isinstance(output, Output)
    # check that spark.read.table called for each table
    spark.read.table.assert_has_calls([call('db_name.table1'), call('db_name.table2')])
    schema1 = rules['tables']['table1']['schema']
    schema2 = rules['tables']['table2']['schema']

    # check that each table rule called once
    rules['tables']['table1']['rules'][0].validate.assert_called_once_with(output=output, df=df, schema=schema1)
    rules['tables']['table1']['rules'][1].validate.assert_called_once_with(output=output, df=df, schema=schema1)
    rules['tables']['table2']['rules'][0].validate.assert_called_once_with(output=output, df=df, schema=schema2)
    rules['tables']['table2']['rules'][1].validate.assert_called_once_with(output=output, df=df, schema=schema2)

    # check that each db rule called once
    rules['rules'][0].validate.assert_called_once_with(output=output, dataframes=dict(table1=df, table2=df))
    rules['rules'][1].validate.assert_called_once_with(output=output, dataframes=dict(table1=df, table2=df))


def test_simple_validation():
    rules = {
        'tables': {
            'table1': {
                'schema': StructType().add("store_id", StringType(), False),
                'rules': [
                    mock.MagicMock(),
                ],
            },
        },
        'rules': [
        ]
    }

    spark = mock.MagicMock()
    df = spark.read.table.return_value = mock.MagicMock()

    validator = Validator(rules=rules)
    assert validator.tables == {'table1'}
    output = validator.validate_db(spark=spark, db_name='db_name')
    assert isinstance(output, Output)

    # check that spark.read.table called for each table
    spark.read.table.assert_has_calls([call('db_name.table1')])
    schema1 = rules['tables']['table1']['schema']

    # check that each table rule called once
    rules['tables']['table1']['rules'][0].validate.assert_called_once_with(output=output, df=df, schema=schema1)


def test_table_read_fail():
    rules = {
        'tables': {
            'table1': {
                'schema': StructType().add("store_id", StringType(), False),
                'rules': [
                    mock.MagicMock(),
                ],
            },
            'table2': {
                'schema': StructType().add("store_id", StringType(), False),
                'rules': [
                    mock.MagicMock()
                ],
            },
        },
        'rules': [
            mock.MagicMock(),
        ]

    }
    spark = mock.MagicMock()
    df = mock.MagicMock()
    spark.read.table.side_effect = [AnalysisException(1, 2), df]

    output = ListOutput()
    validator = Validator(rules=rules)
    output = validator.validate_db(spark=spark, db_name='db_name', output=output)
    output.assert_equal('FAIL Expected "db_name.table1" table to exist, no table found')


    # check that spark.read.table called for each table
    spark.read.table.assert_has_calls([call('db_name.table1'), call('db_name.table2')])
    schema = rules['tables']['table2']['schema']

    # check that only table2 rules are called
    rules['tables']['table1']['rules'][0].validate.assert_not_called()
    rules['tables']['table2']['rules'][0].validate.assert_called_once_with(output=output, df=df, schema=schema)

    # check that only table2 df passed to db rule
    rules['rules'][0].validate.assert_called_once_with(output=output, dataframes=dict(table2=df))
