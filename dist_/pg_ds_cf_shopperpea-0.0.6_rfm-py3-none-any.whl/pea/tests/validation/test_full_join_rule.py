from pyspark.sql.types import StructType, StringType, IntegerType
from pea.tests.validation.conftest import ListOutput
from pea.validation.rule import FullJoinRule


class TestFullJoinRule:

    def test(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), True). \
            add("col2", StringType(), True). \
            add("col3", StringType(), True)

        l = [
            [1, 'a', 'data1'],
            [2, 'b', 'data2'],
        ]
        r = [
            [1, 'a', 'data1'],
            [3, 'c', 'data3']
        ]
        ldf = spark.createDataFrame(l, schema=schema)
        rdf = spark.createDataFrame(r, schema=schema)
        output = ListOutput()
        FullJoinRule(left_table='ldf', right_table='rdf', columns=['col1', 'col2']).\
            validate(output=output, dataframes=dict(ldf=ldf, rdf=rdf))
        expected = '''
FAIL Expected no rows from "ldf" can not join with "rdf" on (col1 col2) columns, found 1 samples:
+----+----+----+----+
|col1|col2|col1|col2|
+----+----+----+----+
|null|null|   3|   c|
+----+----+----+----+

FAIL Expected no rows from "rdf" can not join with "ldf" on (col1 col2) columns, found 1 samples:
+----+----+----+----+
|col1|col2|col1|col2|
+----+----+----+----+
|   2|   b|null|null|
+----+----+----+----+
'''
        output.assert_equal(expected)

    def test_table_not_found_warn(self, spark):
        output = ListOutput()
        FullJoinRule(left_table='incorrect1', right_table='incorrect2', columns=['col1', 'col2']).\
            validate(output=output, dataframes=dict(ldf=None, rdf=None))
        expected = [('WARN', 'Expected "incorrect1" table to exist(or dataframe to be provided) for join validation'),
                    ('WARN', 'Expected "incorrect2" table to exist(or dataframe to be provided) for join validation')]
        assert output == expected
