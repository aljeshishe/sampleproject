from pyspark.sql.types import StructType, IntegerType

from pea.validation import ConsoleOutput, FAIL, INFO


def test_with_prefix(capsys):
    output = ConsoleOutput(prefix='prefix1:')
    with output.with_prefix('prefix2:') as output:
        output.check_is_true(False,
                             status=FAIL,
                             message='message1',
                             fail_postfix='postfix1')
        with output.with_prefix('prefix3:') as output:
            output.check_is_true(False,
                        status=FAIL,
                        message='message2',
                        fail_postfix='postfix2')
        output.check_is_true(False,
                             status=FAIL,
                             message='message3',
                             fail_postfix='postfix3')
    output.check_is_true(False,
                         status=FAIL,
                         message='message4',
                         fail_postfix='postfix4')

    expected = '''prefix1:prefix2:FAIL: message1, postfix1
prefix1:prefix2:prefix3:FAIL: message2, postfix2
prefix1:prefix2:FAIL: message3, postfix3
prefix1:FAIL: message4, postfix4
'''
    assert capsys.readouterr().out == expected


def test_check_is_true_with_false(capsys):
    output = ConsoleOutput()
    output.check_is_true(False,
                         status=FAIL,
                         message='message',
                         fail_postfix='postfix')
    assert capsys.readouterr().out == 'FAIL: message, postfix\n'


def test_check_is_true_with_false_info_status(capsys):
    output = ConsoleOutput()
    output.check_is_true(False,
                         status=INFO,
                         message='message',
                         fail_postfix='postfix')
    assert capsys.readouterr().out == 'INFO: message, postfix\n'


def test_check_is_true_with_true(capsys):
    output = ConsoleOutput()
    output.check_is_true(True,
                         status=FAIL,
                         message='message',
                         fail_postfix='postfix')
    assert capsys.readouterr().out == ''


def test_check_is_true_with_true1(capsys):
    output = ConsoleOutput(show_pass=True)
    output.check_is_true(True,
                         status=FAIL,
                         message='message',
                         fail_postfix='postfix')
    assert capsys.readouterr().out == 'PASS: message\n'


def test_check_df_is_empty(spark, capsys):
    schema = StructType(). \
        add("col1", IntegerType(), False). \
        add("col2", IntegerType(), False)

    data = [[1, 2],
            [2, 3],
            [4, 5],
            [5, 6],
            [7, 8],
            [0, 1]]
    df = spark.createDataFrame(data, schema=schema)
    output = ConsoleOutput()
    output.check_df_is_empty(status=FAIL,
                             df=df,
                             message='message')
    expected = '''FAIL: message, found 6 samples:
+----+----+
|col1|col2|
+----+----+
|   1|   2|
|   2|   3|
|   4|   5|
|   5|   6|
|   7|   8|
+----+----+
only showing top 5 rows

'''
    assert capsys.readouterr().out == expected


def test_check_df_is_empty_with_10_samples(spark, capsys):
    schema = StructType(). \
        add("col1", IntegerType(), False). \
        add("col2", IntegerType(), False)

    data = [[1, 2],
            [2, 3],
            [4, 5],
            [5, 6],
            [7, 8],
            [0, 1]]
    df = spark.createDataFrame(data, schema=schema)
    output = ConsoleOutput(samples=10)
    output.check_df_is_empty(status=FAIL,
                             df=df,
                             message='message')
    expected = '''FAIL: message, found 6 samples:
+----+----+
|col1|col2|
+----+----+
|   1|   2|
|   2|   3|
|   4|   5|
|   5|   6|
|   7|   8|
|   0|   1|
+----+----+

'''
    assert capsys.readouterr().out == expected
