from pyspark.sql.types import StructType, StringType, IntegerType, DoubleType, FloatType

from pea.tests.validation.conftest import ListOutput
from pea.validation.rule import ValidateSchemaRule


def test_valid_schema(spark):
    schema = StructType(). \
        add("col1", StringType(), False). \
        add("col2", StringType(), False)

    df = spark.createDataFrame([['a', 'b']], schema=schema)
    output = ListOutput()
    ValidateSchemaRule().validate(output=output, df=df, schema=schema)
    assert output == []


def test_same_columns(spark):
    actual_schema = StructType(). \
        add("same_1", StringType(), False). \
        add("same_2", IntegerType(), False)
    expected_schema = StructType(). \
        add("same_1", StringType(), False). \
        add("same_2", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == []


def test_unexpected_columns(spark):
    actual_schema = StructType(). \
        add("same_1", StringType(), False). \
        add("same_2", IntegerType(), False)
    expected_schema = StructType()
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == [('FAIL',
                       'Expected no unexpected columns, found unexpected columns (same_1 same_2)')]


def test_missing_columns(spark):
    actual_schema = StructType()
    expected_schema = StructType(). \
        add("same_1", StringType(), False). \
        add("same_2", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == [('FAIL',
                       'Expected no missing columns, found missing columns: (same_1 same_2)')]


def test_ignore_metadata(spark):
    actual_schema = StructType(). \
        add("same_1", StringType(), False, dict(key=True)). \
        add("same_2", IntegerType(), False)
    expected_schema = StructType(). \
        add("same_1", StringType(), False). \
        add("same_2", IntegerType(), False, dict(key=True))
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == []


def test_unexpected_and_same_columns(spark):
    actual_schema = StructType(). \
        add("unexpected_1", DoubleType(), True). \
        add("unexpected_2", StringType(), False). \
        add("same_1", IntegerType(), False)
    expected_schema = StructType(). \
        add("same_1", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == [('FAIL',
                       'Expected no unexpected columns, found unexpected columns (unexpected_1 unexpected_2)')]


def test_missing_and_same_columns(spark):
    actual_schema = StructType(). \
        add("same_1", IntegerType(), False)
    expected_schema = StructType(). \
        add("missing_1", DoubleType(), True). \
        add("missing_2", StringType(), False). \
        add("same_1", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    assert output == [('FAIL',
                       'Expected no missing columns, found missing columns: (missing_1 missing_2)')]


def test_different_types(spark):
    actual_schema = StructType(). \
        add("type_1", DoubleType(), False). \
        add("type_2", IntegerType(), False). \
        add("same_1", IntegerType(), False)
    expected_schema = StructType(). \
        add("type_1", StringType(), False). \
        add("type_2", FloatType(), False). \
        add("same_1", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    expected = [('FAIL', 'Expected column "type_1" to be "StringType", found "DoubleType"'),
                ('FAIL', 'Expected column "type_2" to be "FloatType", found "IntegerType"')]
    assert output == expected


def test_different_nullable(spark):
    actual_schema = StructType(). \
        add("nullable_1", IntegerType(), True). \
        add("nullable_2", IntegerType(), False). \
        add("same_1", IntegerType(), False)
    expected_schema = StructType(). \
        add("nullable_1", IntegerType(), False). \
        add("nullable_2", IntegerType(), True). \
        add("same_1", IntegerType(), False)
    output = ListOutput()
    ValidateSchemaRule._validate(output=output, actual_schema=actual_schema, expected_schema=expected_schema)
    expected = [('WARN', 'Expected column "nullable_1" nullable to be "False", found "True"'),
                ('WARN', 'Expected column "nullable_2" nullable to be "True", found "False"')]
    assert output == expected