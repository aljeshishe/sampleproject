from pyspark.sql.types import StructType, FloatType, BooleanType, IntegerType

from pea.tests.validation.conftest import ListOutput
from pea.validation.rule import NoNullsOrNansRule


class TestNoNullsOrNansRule:

    def test(self, spark):
        schema = StructType(). \
            add("col1", FloatType(), True). \
            add("col2", BooleanType(), True). \
            add("col3", IntegerType(), True)

        data = [
            [1.1, True, 1],             # all PASS
            [None, None, None],         # all FAIL
            [float('nan'), False, 0]    # float('nan') will fail
        ]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoNullsOrNansRule(['col1', 'col2', 'col3']).validate(output=output, df=df, schema=schema)
        expected = '''
FAIL Expected no Null or Nan values in "col1" column expected, found 2 samples:
+----+
|col1|
+----+
|null|
| NaN|
+----+

FAIL Expected no Null or Nan values in "col2" column expected, found 1 samples:
+----+
|col2|
+----+
|null|
+----+

FAIL Expected no Null or Nan values in "col3" column expected, found 1 samples:
+----+
|col3|
+----+
|null|
+----+
'''
        output.assert_equal(expected)