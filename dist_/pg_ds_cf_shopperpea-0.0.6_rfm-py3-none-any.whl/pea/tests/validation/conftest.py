import pytest
from pyspark.sql import SparkSession
import json

from pea.validation.output import Output


@pytest.fixture(scope="session")
def spark():
    spark = (SparkSession.builder.master("local[*]").appName("python_mozetl_test").getOrCreate())
    yield spark
    spark.stop()


@pytest.fixture
def spark_context(spark):
    return spark.sparkContext


class ListOutput(Output, list):
    def message(self, status, message, prefixes):
        self.append((status, message))

    def __str__(self):
        return '\n'.join(map(lambda o: ' '.join(o), self))

    def assert_equal(self, expected):
        print(self)
        assert str(self) == expected.lstrip('\n')