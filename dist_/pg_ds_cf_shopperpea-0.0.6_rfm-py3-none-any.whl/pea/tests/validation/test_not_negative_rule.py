from pyspark.sql.types import StructType, IntegerType

from pea.tests.validation.conftest import ListOutput
from pea.validation.output import INFO
from pea.validation.rule import NoNegativesRule


class TestNotNegativeRule:

    def test_found_negative_values(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [-1, 2, 3],
                [1, -2, 3],
                [1, 2, -3]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoNegativesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        expected = '''
FAIL Expected no negative values in "col1" column, found 1 samples:
+----+
|col1|
+----+
|  -1|
+----+

FAIL Expected no negative values in "col2" column, found 1 samples:
+----+
|col2|
+----+
|  -2|
+----+
'''
        output.assert_equal(expected)

    def test_found_negative_values_and_info_status(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False, dict(key=True)). \
            add("col2", IntegerType(), False)

        data = [[1, 2],
                [-1, 2],
                [1, -2]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoNegativesRule(['col2'], status=INFO).validate(output=output, df=df, schema=schema)
        expected = '''
INFO Expected no negative values in "col2" column, found 1 samples:
+----+----+
|col1|col2|
+----+----+
|   1|  -2|
+----+----+
'''
        output.assert_equal(expected)

    def test_found_negative_values_proper_columns(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [-1, 2, 3],
                [1, -2, 3],
                [1, 2, -3]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoNegativesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        expected = '''
FAIL Expected no negative values in "col1" column, found 1 samples:
+----+
|col1|
+----+
|  -1|
+----+

FAIL Expected no negative values in "col2" column, found 1 samples:
+----+
|col2|
+----+
|  -2|
+----+
'''
        output.assert_equal(expected)

    def test_no_negative_values(self, spark):
        schema = StructType(). \
            add("col1", IntegerType(), False). \
            add("col2", IntegerType(), False). \
            add("col3", IntegerType(), False)

        data = [[1, 2, 3],
                [4, 5, 6]]
        df = spark.createDataFrame(data, schema=schema)
        output = ListOutput()
        NoNegativesRule(['col1', 'col2']).validate(output=output, df=df, schema=schema)
        assert output == []