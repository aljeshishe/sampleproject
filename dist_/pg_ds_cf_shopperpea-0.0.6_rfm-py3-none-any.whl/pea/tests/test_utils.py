import pandas as pd
import numpy as np
from pandas.testing import assert_frame_equal
from pea.utils import melt
from pea.eda import count_nulls


def test_melt_df_all_correct(spark_session):
    pd_df = pd.DataFrame({"A": {0: "a", 1: "b", 2: "c"}, "B": {0: 1, 1: 3, 2: 5}})
    df = spark_session.createDataFrame(pd_df)
    actual = melt(df, id_vars=["A"], value_vars=["B"]).toPandas()
    expected = pd.DataFrame(
        {
            "A": {0: "a", 1: "b", 2: "c"},
            "variable": {0: "B", 1: "B", 2: "B"},
            "value": {0: 1, 1: 3, 2: 5},
        }
    )
    assert_frame_equal(expected, actual, check_like=True)


def test_count_nulls(spark_session):
    pd_df = pd.DataFrame({"a": [0, np.nan, np.nan], "b": ["a", None, "b"]})
    df = spark_session.createDataFrame(pd_df)
    actual = count_nulls(df).toPandas()
    print(actual)
    expected = pd.DataFrame({"a": [2], "a_pct": [0.6666666], "b": [1], "b_pct": [0.3333333333]})
    assert_frame_equal(expected, actual, check_like=True)
