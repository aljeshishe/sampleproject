import numpy as np
import pandas as pd
import pytest
from pathlib import Path

from pea.data import load_demo_pos

TEST_DATA = Path(__file__).parent / "data"


@pytest.fixture
def demoPOS() -> pd.DataFrame:
    return load_demo_pos()


@pytest.fixture
def prepped_weekly_pos() -> pd.DataFrame:
    df = pd.read_parquet(TEST_DATA / "prepped_weekly_pos.parquet")
    df["Product"] = df["Product"].astype(np.int64)
    return df


@pytest.fixture
def ref_price(prepped_weekly_pos):
    ref_pr = pd.read_parquet(TEST_DATA / "ref_price.parquet")
    df = pd.concat([prepped_weekly_pos, ref_pr], axis=1)
    return df


@pytest.fixture
def promo_peaks(ref_price) -> pd.DataFrame:
    promo_peaks = pd.read_parquet(TEST_DATA / "promo_peaks.parquet")
    df = pd.concat([ref_price, promo_peaks[["Promo_NonPrice", "Promo"]]], axis=1)
    return df
